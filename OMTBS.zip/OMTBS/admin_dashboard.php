<?php 
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_styles.css">
    <style>
        /* General Styles */
        body {
           font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background-image: url("myke-simon-atsUqIm3wxo-unsplash.jpg");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4); /* Dark overlay */
            z-index: -1;
        }

        /* Header Navigation */
        header {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 15px 30px;
        }

        header nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            align-items: center;
            justify-content: flex-end;
        }

        header nav ul li {
            margin-left: 20px;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        header nav ul li a:hover {
            color: #f8f9fa;
            text-decoration: underline;
        }

        /* Main Section */
        section {
            padding: 60px 20px;
            text-align: center;
        }

        section h1 {
            font-size: 32px;
            color: white;
            margin-bottom: 20px;
        }

        section p {
            font-size: 18px;
            color: #f8f9fa;
            margin-bottom: 40px;
        }

        /* Dashboard Cards */
        .dashboard {
            display:flexbox;
            gap: 30px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .card {
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 200px;
            text-align: center;
            backdrop-filter: blur(5px); /* Optional: adds a blur effect behind the card */
            margin-top: 100px;
            background-color: transparent;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
            background-color: rgba(1, 3, 3, 0.9);
        }

        .card h2 {
            font-size: 24px;
            color: mediumaquamarine;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        /* Footer Styling (Optional) */
        footer {
            margin-top: 140px;
            padding: 10px;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            text-align: center;
        }

        footer p {
            margin: 0;
        }

        /* Media Queries for Mobile Devices */
        @media (max-width: 768px) {
            section {
                padding: 20px;
            }

            .dashboard {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 100%;
                max-width: 400px;
            }
        }
    </style>
</head>

<body>
    <!-- Header Navigation -->
    <header>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="add_movie.php">Add Movie</a></li>
                <li><a href="view_users.php">View Users</a></li>
                <li><a href="view_payments.php">View Payments</a></li>
                <li><a href="home_page.php">Home Page</a></li>
                <li><a href="report.php">View Report</a></li>

            </ul>
        </nav>
    </header>

    <!-- Main Content -->
    <section>
        <!-- Dashboard Cards -->
        <div class="dashboard">
            <div class="card">
                <h2>Manage Movies</h2>
                <a href="add_movie.php" class="btn">Add Movie</a>
                <a href="delete_movie.php" class="btn">Delete Movie</a>
            </div>
            <div class="card">
                <h2>View Users</h2>
                <a href="view_users.php" class="btn">View Users</a>
            </div>
            <div class="card">
                <h2>View Payments</h2>
                <a href="view_payments.php" class="btn">View Payments</a>
            </div>
          
            <div class="card">
                <h2>View Report</h2>
                <a href="report.php" class="btn">View Report</a>
            </div>
        </div>
    </section>

    <!-- Optional Footer -->
    <footer>
        <p>&copy; 2024 Movie Booking Admin</p>
    </footer>
</body>

</html>
