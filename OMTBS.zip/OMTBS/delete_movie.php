<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit();
}

// Include database connection
require 'db_connection.php';

// Fetch movies from the database
$query = "SELECT id, name FROM movies";
$result = mysqli_query($conn, $query);
$movies = mysqli_fetch_all($result, MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $movie_id = $_POST['movie_id'];

    // Delete movie from the database
    $delete_query = "DELETE FROM movies WHERE id = $movie_id";
    if ($conn->query($delete_query) === TRUE) {
        echo "<script>alert('Movie deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting movie: " . $conn->error . "');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Movie</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Container for the delete form */
        .delete-movie-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h1 {
            text-align: center;
            font-size: 24px;
            color: #343a40;
            margin-bottom: 20px;
        }

        /* Label and select styles */
        label {
            font-size: 14px;
            color: #495057;
            display: block;
            margin-bottom: 10px;
        }

        select {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            background-color: #fff;
            margin-bottom: 20px;
            transition: border-color 0.3s;
        }

        select:focus {
            border-color: #007bff;
            outline: none;
        }

        /* Delete button styles */
        button {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #c82333;
        }

        /* Mobile responsiveness */
        @media (max-width: 500px) {
            .delete-movie-container {
                padding: 20px;
            }

            h1 {
                font-size: 20px;
            }

            button {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="delete-movie-container">
        <h1>Delete Movie</h1>
        <form action="delete_movie.php" method="POST">
            <label for="movie_id">Select Movie to Delete:</label>
            <select id="movie_id" name="movie_id" required>
                <option value="">-- Select a Movie --</option>
                <?php foreach ($movies as $movie): ?>
                    <option value="<?= $movie['id'] ?>"><?= htmlspecialchars($movie['name']) ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Delete Movie</button>
        </form>
    </div>
</body>

</html>
