<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="style.css"> <!-- Optional: Link to your CSS file -->
    <style>
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 75px;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
            background: url('jakob-owens-CiUR8zISX60-unsplash.jpg') no-repeat center center/cover;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Make body take full viewport height */
        }

        header {
            background-color: transparent;
            color: white;
            padding: 1px 0;
        }

        h1 {
            margin: 20px 0;
        }

        .contact-info {
            
            margin: 40px;
            padding: 20px;
            background-color: white;
            border-radius: 30px;
            height: 300px;
            width: 300px;
            color: black;
            display: flex;
            flex-direction: column;
            align-items: center; /* Center content inside the contact-info box */
            justify-content: center; /* Center content inside the contact-info box */
        }

        .social-icons {
            margin-top: 20px;
        }

        .social-icons a {
            margin: 0 15px;
            text-decoration: none;
            color: #333;
        }

        .social-icons img {
            width: 30px;
            height: 30px;
        }

        footer {
            margin-top: 110px;
            padding: 10px 0;
            background-color: transparent;
            color: black;
            font-weight: bolder;
        }
    </style>
</head>

<body>
    <header>
        <!-- <h1>Movie Ticket Booking System (Contact Us)</h1> -->
    </header>

    <div class="contact-info">
        <h2>Movie Ticket Booking System Contact Details</h2>
        <p>Email: sarthakpomane123@gmail.com</p>
        <p>Email: abhijeetsatav@gmail.com</p>
        <p>Address: Carnival Cinemas, Subhdra Mall, Baramati</p>
        
        <div class="social-icons">
            <a href="https://www.instagram.com/yourInstagramHandle" target="_blank">
                <img src="insta_logo.jpg" alt="Instagram">
            </a>
            <a href="https://www.facebook.com/yourFacebookPage" target="_blank">
                <img src="fb.png" alt="Facebook">
            </a>
        </div>
    </div>

    <!-- <footer>
        <p>&copy; 2024 MovieBooking. All rights reserved.</p>
    </footer> -->
</body>

</html>
