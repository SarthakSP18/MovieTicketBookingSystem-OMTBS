<?php
session_start();
require 'db_connection.php'; // Ensure you have your database connection here

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to fetch the admin user by username
    $query = "SELECT * FROM admin WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if ($admin) {
        // Verify the hashed password
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;

            // Personalized greeting based on username
            if ($username === 'sarthak') {
                echo "<script>alert('Welcome Back Sarthak (Admin)');</script>";
            } elseif ($username === 'abhijeet') {
                echo "<script>alert('Welcome Back Abhijeet (Admin)');</script>";
            }

            // Redirect to admin dashboard
            echo "<script>window.location.href = 'admin_dashboard.php';</script>";
        } else {
            // Invalid password
            echo "Invalid login credentials. <a href='admin_login.html'>Try again</a>";
        }
    } else {
        // Admin username not found
        echo "Invalid login credentials. <a href='admin_login.html'>Try again</a>";
    }
}
?>
