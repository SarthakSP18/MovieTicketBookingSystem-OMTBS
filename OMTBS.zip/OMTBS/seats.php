<?php
// seats.php

session_start();
include('db_connection.php'); // Include database connection

$movie_name = isset($_GET['movie']) ? htmlspecialchars($_GET['movie']) : 'Unknown Movie';
$bookedSeats = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_date = $_POST['movie_date'];
    $selected_timing = $_POST['timing'];

    // Fetch already booked seats for the selected movie, date, and timing
    $stmt = $conn->prepare("SELECT seat_number FROM bookings WHERE movie_name = ? AND movie_date = ? AND movie_timing = ?");
    $stmt->bind_param("sss", $movie_name, $selected_date, $selected_timing);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $bookedSeats = array_merge($bookedSeats, explode(', ', $row['seat_number']));
    }
    $stmt->close();

    // Save selected seats to the session and simulate "payment" by displaying booking summary
    if (!empty($_POST['seat_number'])) {
        $_SESSION['movie_name'] = $movie_name;
        $_SESSION['selected_seats'] = explode(',', $_POST['seat_number']);
        $_SESSION['movie_timings'] = $selected_timing;
        $_SESSION['movie_date'] = $selected_date;

        // Display booking confirmation
        $confirmedSeats = implode(", ", $_SESSION['selected_seats']);
        echo "<h1>Booking Confirmation</h1>";
        echo "<p>Movie: $movie_name</p>";
        echo "<p>Date: $selected_date</p>";
        echo "<p>Time: $selected_timing</p>";
        echo "<p>Seats: $confirmedSeats</p>";
        echo '<a href="seats.php">Back to Seat Selection</a>';
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Seats for <?= $movie_name; ?></title>
    <style>
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            background: url('geoffrey-moffett-TFRezw7pQwI-unsplash.jpg') no-repeat center center/cover;
            color: white;
            text-align: center;
            padding-top: 20px;
        }
        .seat-selection {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
        }
        .screen {
            background-color: lightblue;
            color: black;
            padding: 10px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .seat-grid {
            display: flex;
            flex-direction: column;
            gap: 10px;
            color: black;
        }
        .row {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .seat {
            width: 50px;
            height: 50px;
            background-color: #ddd;
            border: 2px solid #333;
            cursor: pointer;
            border-radius: 5px;
            text-align: center;
            line-height: 50px;
        }
        .seat.booked {
            background-color: red;
            cursor: not-allowed;
        }
        .seat.selected {
            background-color: green;
            color: white;
        }
        form {
            margin-top: 20px;
        }
        select, input[type="date"], button {
            padding: 10px;
            margin: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
        }
        button:hover {
            background-color: #218838;
        }
        .seat-summary {
            margin-top: 20px;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <section class="seat-selection">
        <h1>Select Your Seats for <?= $movie_name; ?></h1>
        <div class="screen">Screen This Way</div>

        <form id="seatForm" method="POST" action="">
            <div class="seat-grid">
                <?php
                for ($row = 'A'; $row <= 'H'; $row++) {
                    echo '<div class="row">';
                    for ($seat = 1; $seat <= 10; $seat++) {
                        $seatNumber = $row . $seat;
                        $isBooked = in_array($seatNumber, $bookedSeats);
                        $seatClass = $isBooked ? 'seat booked' : 'seat';
                        echo '<div class="' . $seatClass . '" data-seat="' . $seatNumber . '">' . $seatNumber . '</div>';
                    }
                    echo '</div>';
                }
                ?>
            </div>

            <input type="hidden" name="seat_number" id="selected-seat">
            <input type="hidden" name="movie_name" value="<?= $movie_name; ?>">

            <label for="movie_date">Select Date:</label>
            <input type="date" name="movie_date" id="movie_date" required>

            <label for="timing">Select Timing:</label>
            <select name="timing" id="timing" required>
                <option value="10:00 AM">10:00 AM</option>
                <option value="1:00 PM">1:00 PM</option>
                <option value="4:00 PM">4:00 PM</option>
                <option value="7:00 PM">7:00 PM</option>
            </select>

            <div class="seat-summary">
                <p>Selected Seats: <span id="seatCount">0</span></p>
                <p>Total Amount: ₹<span id="totalAmount">0</span></p>
            </div>

            <button type="submit" id="proceedButton">Confirm Booking</button>
        </form>
    </section>

    <script>
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('movie_date').setAttribute('min', today);

        const seats = document.querySelectorAll('.seat:not(.booked)');
        let selectedSeats = [];
        const seatCount = document.getElementById('seatCount');
        const totalAmount = document.getElementById('totalAmount');
        const seatPrice = 200;

        seats.forEach(seat => {
            seat.addEventListener('click', () => {
                const seatNumber = seat.getAttribute('data-seat');

                if (selectedSeats.includes(seatNumber)) {
                    selectedSeats = selectedSeats.filter(s => s !== seatNumber);
                    seat.classList.remove('selected');
                } else {
                    selectedSeats.push(seatNumber);
                    seat.classList.add('selected');
                }

                document.getElementById('selected-seat').value = selectedSeats.join(',');
                seatCount.textContent = selectedSeats.length;
                totalAmount.textContent = selectedSeats.length * seatPrice;
            });
        });
    </script>
</body>
</html>
