<?php 
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: user_login.php");
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "movie_booking_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$phone_number = "";
$tickets = array();
$user_name = "";

// Check if the search form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['phone_number'])) {
        $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);

        // Basic validation
        if (!empty($phone_number)) {
            // Query to retrieve tickets and user details for the given phone number
            $query = "
                SELECT u.full_name, b.movie_name, b.seat_number, b.movie_timing, b.movie_date 
                FROM bookings b 
                JOIN users u ON b.user_id = u.id 
                WHERE u.phone = '$phone_number'
            ";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                // Fetching tickets and user name for the phone number
                while ($row = $result->fetch_assoc()) {
                    $tickets[] = $row;
                    $user_name = $row['full_name']; // Get user full name
                }
            } else {
                // No tickets found for this phone number
                $tickets = [];
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Ticket Booking System (User Dashboard)</title>
    <style>
        /* General styles */
        body {
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            margin: 0;
            padding: 0;
            background: url('user_bg2.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            z-index: -1;
        }

        header {
            background-color: black;
            padding: 1px;
            color: white;
            text-align: center;
            position: relative;
            z-index: 1;
        }
.header:a{
    color: black;
    background-color: white;
}
        section {
            padding: 40px 20px;
            text-align: center;
            color: white;
            position: relative;
            z-index: 1;
        }

        h1 {
            font-size: 40px;
            color: wheat;
            margin-bottom: 3px;
            
        }
        h2{
            font-size: 30px;
        }

        .tickets-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .ticket-card {
            background-color: rgba(255, 255, 255, 0.9);
            border: 2px solid #333;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 300px;
            text-align: center;
            transition: transform 0.3s ease;
            position: relative;
        }

        .ticket-card:hover {
            transform: scale(1.05);
        }

        .ticket-card h2 {
            font-size: 22px;
            color: #333;
        }

        .ticket-details {
            font-size: 16px;
            color: #555;
            margin-top: 10px;
        }

        .btn {
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 600;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
            margin-top: 20px;
            display: inline-block;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .no-ticket-message {
            font-size: 22px;
            color: #f8f9fa;
            margin-top: 40px;
        }

        /* Search bar */
        .search-bar {
            margin-bottom: 30px;
        }

        .search-bar input {
            padding: 10px;
            font-size: 16px;
            width: 300px;
            border-radius: 5px;
            border: none;
            margin-right: 10px;
        }

        .search-bar button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #218838;
        }

        .print-button {
            position: absolute;
            top: 250px;
            right: 6rem;
        }

        .print-button button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .print-button button:hover {
            background-color: #218838;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .ticket-card {
                width: 100%;
            }

            header h1 {
                font-size: 28px;
            }

            h1 {
                font-size: 28px;
            }
        }
    </style>

    <script>
        // Print ticket
        function printTicket(ticketId) {
            const ticketContent = document.getElementById(ticketId).innerHTML;
            const originalContent = document.body.innerHTML;

            document.body.innerHTML = ticketContent;
            window.print();
            document.body.innerHTML = originalContent;
            location.reload(); // Reload the page to restore content
        }
    </script>
</head>

<body>
    <!-- Overlay for the background -->
    <div class="overlay"></div>

    <header> <div class="header">
        <h1>Movie Ticket Booking System (User Dashboard)</h1>
       <a href="home_page.php" style="color: grey;" >Goto HomePage & Buy Tickets !!!</a></div>
    </header>

    <section>
        <h2>Your Tickets</h2>
        
        <!-- Search bar for phone number -->
        <div class="search-bar">
            <form method="POST" action="user_dashboard.php">
                <input type="text" name="phone_number" placeholder="Enter your phone number" required>
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="tickets-container">
            <?php if (empty($tickets)) : ?>
                <p class="no-ticket-message">Enter your number and Search <br> <a href="home_page.php" class="btn">Go to Home and Buy Tickets</a></p>
            <?php else : ?>
                <?php foreach ($tickets as $index => $ticket) : ?>
                    <div class="ticket-card" id="ticket-<?php echo $index; ?>">
                        <h2><?php echo htmlspecialchars($ticket['movie_name']); ?></h2>
                        <div class="ticket-details">
                            <p>User Name: <?php echo htmlspecialchars($user_name); ?></p>
                            <p>Seat Number: <?php echo htmlspecialchars($ticket['seat_number']); ?></p>
                            <p>Show Timings: <?php echo htmlspecialchars($ticket['movie_timing']); ?></p>
                            <p>Movie Date: <?php echo htmlspecialchars($ticket['movie_date']); ?></p>
                        </div>

                        <!-- Download/Print Button -->
                        <div class="print-button">
                            <button onclick="printTicket('ticket-<?php echo $index; ?>')">Download/Print</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
</body>

</html>
