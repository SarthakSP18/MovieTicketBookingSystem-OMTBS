<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "movie_booking_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get ticket details from URL parameters
$movie_id = $_GET['movie_id'];
$seat_number = $_GET['seat_number'];
$amount = $_GET['amount'];

// Fetch movie details
$stmt = $conn->prepare("SELECT title FROM movies WHERE id = ?");
$stmt->bind_param("i", $movie_id);
$stmt->execute();
$result = $stmt->get_result();
$movie = $result->fetch_assoc();
$title = $movie['title'];

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Ticket</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        
        h1 {
    text-align: center;
    margin-top: 20px;
}

.ticket {
    background: white;
    padding: 20px;
    max-width: 500px;
    margin: 20px auto;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.ticket p {
    font-size: 18px;
    margin: 10px 0;
}


        .ticket-details {
            margin: 20px 0;
        }

        .ticket-details p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="ticket">
        <h1>Movie Ticket</h1>
        <div class="ticket-details">
            <p><strong>Movie Title:</strong> <?php echo htmlspecialchars($title); ?></p>
            <p><strong>Seat Number:</strong> <?php echo htmlspecialchars($seat_number); ?></p>
            <p><strong>Amount Paid:</strong> ₹<?php echo htmlspecialchars($amount); ?></p>
        </div>
        <p>Thank you for booking with us!</p>
    </div>
</body>
</html>
