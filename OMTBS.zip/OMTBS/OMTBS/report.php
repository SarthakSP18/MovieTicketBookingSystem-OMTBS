<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit();
}

require 'db_connection.php';

// Fetch total visitors count (assuming 'statistics' table exists)
$visitor_query = "SELECT visitor_count AS total_visitors FROM statistics WHERE id = 1"; 
$visitor_result = $conn->query($visitor_query);

if ($visitor_result && $visitor_data = $visitor_result->fetch_assoc()) {
    $total_visitors = $visitor_data['total_visitors'];
} else {
    $total_visitors = 0; // Default in case of an error
}

// Fetch total booked seats
$seats_query = "SELECT SUM(LENGTH(seat_number) - LENGTH(REPLACE(seat_number, ',', '')) + 1) AS total_booked_seats FROM bookings"; 
$seats_result = $conn->query($seats_query);

if ($seats_result && $seats_data = $seats_result->fetch_assoc()) {
    $total_booked_seats = $seats_data['total_booked_seats'] ?: 0; // Default in case of an error
} else {
    $total_booked_seats = 0; // Default in case of an error
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Report</title>
    <link rel="stylesheet" href="admin_styles.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url("admin_bg.jpg");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4); /* Dark overlay */
            z-index: -1;
        }

        header {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 15px 30px;
        }

        header nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            align-items: center;
            justify-content: flex-end;
        }

        header nav ul li {
            margin-left: 20px;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        header nav ul li a:hover {
            color: #f8f9fa;
            text-decoration: underline;
        }

        section {
            padding: 60px 20px;
            text-align: center;
        }

        h1 {
            font-size: 32px;
            color: white;
            margin-bottom: 20px;
        }

        .report-container {
            display: inline-block;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        .report-container h2 {
            color: #343a40;
            font-size: 24px;
            margin-bottom: 10px;
        }

        .report-container p {
            font-size: 20px;
            margin: 10px 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>

    <header>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="add_movie.php">Add Movie</a></li>
                <li><a href="view_users.php">View Users</a></li>
                <li><a href="view_payments.php">View Payments</a></li>
                <li><a href="home_page.php">Home Page</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <h1>Admin Report</h1>
        <div class="report-container">
            <h2>Site Statistics</h2>
            <p>Total Visitors: <strong><?php echo $total_visitors; ?></strong></p>
            <p>Total Seats Booked: <strong><?php echo $total_booked_seats; ?></strong></p>
            <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
        </div>
    </section>

</body>

</html>
