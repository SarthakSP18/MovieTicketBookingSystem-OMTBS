<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "movie_booking_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $transaction_id = $_POST['transaction_id'];
    $amount = $_POST['amount'];
    $movie_id = $_POST['movie_id'];
    $seat_number = $_POST['seat_number'];

    // Sanitize user input to prevent SQL injection
    $transaction_id = mysqli_real_escape_string($conn, $transaction_id);
    $amount = mysqli_real_escape_string($conn, $amount);
    $movie_id = mysqli_real_escape_string($conn, $movie_id);
    $seat_number = mysqli_real_escape_string($conn, $seat_number);

    // Insert payment information into the database
    $query = "INSERT INTO payments (transaction_id, amount, movie_id, seat_number) VALUES ('$transaction_id', '$amount', '$movie_id', '$seat_number')";

    if ($conn->query($query) === TRUE) {
        $message = "Payment Verified Successfully!";
        
        // Fetch movie details for ticket
        $movieQuery = "SELECT title FROM movies WHERE id='$movie_id'";
        $movieResult = $conn->query($movieQuery);
        $movieTitle = $movieResult->fetch_assoc()['title'];

        // Generate ticket
        echo "<h1>Movie Ticket</h1>";
        echo "<p>Movie: " . htmlspecialchars($movieTitle) . "</p>";
        echo "<p>Seat Number: " . htmlspecialchars($seat_number) . "</p>";
        echo "<p>Amount Paid: ₹" . htmlspecialchars($amount) . "</p>";
        echo "<p>Transaction ID: " . htmlspecialchars($transaction_id) . "</p>";
    } else {
        $message = "Error: " . $conn->error;
    }

    // Close connection
    $conn->close();
} else {
    header("Location: home_page.html");
    exit();
}
?>
