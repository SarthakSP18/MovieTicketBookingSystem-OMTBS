<?php
session_start(); // Start the session

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "movie_booking_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if mobile number and password are set
    if (isset($_POST['mobile_number']) && isset($_POST['password'])) {
        $phone = $_POST['mobile_number']; // Changed from phone to mobile_number
        $password = $_POST['password'];

        // Basic validation
        if (empty($phone) || empty($password)) {
            $message = "Please fill in all fields.";
        } else {
            // Sanitize user input
            $phone = mysqli_real_escape_string($conn, $phone);

            // Check if the mobile number exists
            $query = "SELECT * FROM users WHERE phone='$phone'"; // Ensure the column name matches your database
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();

                // Verify password
                if (password_verify($password, $user['password'])) {
                    // Password is correct
                    $_SESSION['phone'] = $phone; // Set session variable for logged-in user
                    $_SESSION['user_logged_in'] = true; // Set a session variable to check login status
                    $_SESSION['user_id'] = $user['id']; // Store user ID in session if needed

                    // Redirect to user dashboard
                    header("Location: user_dashboard.php");
                    exit(); // Always exit after header redirection
                } else {
                    // Invalid password
                    $message = "Incorrect password. Please try again.";
                }
            } else {
                // Mobile number doesn't exist
                $message = "User with the given mobile number not found. Please Book Ticket & Login";
            }
        }
    } else {
        $message = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <style>
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            background-color: #f4f4f4;
            padding-top: 60px;
            background: url('billy-aboulkheir-7d94sU14YXA-unsplash.jpg') no-repeat center center/cover;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
          
        }

        .login-container {
            background-color: transparent;
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: black;
            font-weight: bolder;
        }

        .input-group {
            margin-bottom: 15px;
            position: relative;
            color: white;
        }

        .input-group label {
            display:flex;
            margin-bottom: 2px;
        }

        .input-group input {
            width: 94%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .toggle-password {
            position: absolute;
            left: 180px;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: none;
            font-size: 16px; /* Smaller size */
            color: #007bff;
            cursor: pointer;
            padding: 0; /* Remove extra padding */
            height: 1px; /* Control the height */
        }

        button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background-color: #28a745;
            color: black;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: Georgia, 'Times New Roman', Times, serif;
            font-weight:bolder;

        }

        .error-message {
            background-color: #ffdddd;
            color: #d8000c;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        p a {
            color: #007bff;
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>User Login</h2>
        <?php if ($message != ''): ?>
            <div class="error-message"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="user_login.php" method="POST">
            <div class="input-group">
                <label for="mobile_number">Mobile Number:</label>
                <input type="text" name="mobile_number" id="mobile_number" required>
            </div>
            <div class="input-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
                <button type="button" class="toggle-password" onclick="togglePassword('password')">👁️</button>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>

    <script>
        function togglePassword(inputId) {
            const passwordInput = document.getElementById(inputId);
            const toggleButton = document.querySelector(`.toggle-password[onclick="togglePassword('${inputId}')"]`);
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleButton.innerHTML = '👁️‍🗨️'; // Change icon to indicate visibility
            } else {
                passwordInput.type = 'password';
                toggleButton.innerHTML = '👁️'; // Change icon back to hidden
            }
        }
    </script>
</body>

</html>
