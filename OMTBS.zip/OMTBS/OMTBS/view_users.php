<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit();
}

include('db_connection.php'); // Database connection

// Fetch users and their bookings from the database
$query = "
    SELECT u.id, u.full_name, u.email, u.phone, u.created_at, u.dob,
           b.movie_name, b.movie_timing, b.seat_number, b.booking_time
    FROM users u 
    LEFT JOIN bookings b ON u.id = b.user_id";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <link rel="stylesheet" href="admin_styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="add_movie.php">Add Movie</a></li>
                <li><a href="view_users.php">View Users</a></li>
                <li><a href="view_payments.php">View Payments</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <h1>View Users</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone No.</th>
                    <th>Created At</th>
                    <th>Movie Title</th>
                    <th>Show Time</th>
                    <th>Seat Number</th>
                    <th>Booking Time</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td><?php echo $row['movie_name'] ? $row['movie_name'] : 'N/A'; ?></td>
                    <td><?php echo $row['movie_timing'] ? $row['movie_timing'] : 'N/A'; ?></td>
                    <td><?php echo $row['seat_number'] ? $row['seat_number'] : 'N/A'; ?></td>
                    <td><?php echo $row['booking_time'] ? $row['booking_time'] : 'N/A'; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </section>

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</body>
</html>
