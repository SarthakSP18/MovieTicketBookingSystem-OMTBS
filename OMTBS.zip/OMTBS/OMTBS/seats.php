<?php
// seats.php

// Start the session to store selected movie and seats later
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Save movie name, selected seats, selected timing, and selected date to the session
    $movie_name = $_POST['movie_name'];
    $selected_seats = explode(',', $_POST['seat_number']);
    $selected_timing = $_POST['timing']; // Get the selected timing
    $selected_date = $_POST['movie_date']; // Get the selected date

    // Store in session
    $_SESSION['movie_name'] = $movie_name;
    $_SESSION['selected_seats'] = $selected_seats;
    $_SESSION['movie_timings'] = $selected_timing; // Store selected timing
    $_SESSION['movie_date'] = $selected_date; // Store selected date

    // Redirect to payment page
    header('Location: payment.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Seats for <?= isset($_GET['movie']) ? htmlspecialchars($_GET['movie']) : 'Unknown Movie'; ?></title>
    <style>
        /* General page styles */
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            background: url('geoffrey-moffett-TFRezw7pQwI-unsplash.jpg') no-repeat center center/cover;
            color: white;
            padding: 100px 0;
            text-align: center;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
            font-weight: bold;

        }

        header {
            background-color: #333;
            color: white;
            padding: 10px 20px;
        }

        header nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        header nav ul li {
            display: inline;
            margin-right: 20px;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
        }

        .seat-selection {
            max-width: 900px;
            margin: 50px auto;
            text-align: center;
        }

        .screen {
            background-color: lightblue;
            color: black;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 18px;
            text-transform: uppercase;
            font-weight: bold;
        }

        /* Seat grid layout */
        .seat-grid {
            display: flex;
            flex-direction: column;
            gap: 10px;
            justify-content: center;
            color: black;
        }

        .row {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .seat {
            width: 50px;
            height: 50px;
            background-color: #ddd;
            border: 2px solid #333;
            cursor: pointer;
            border-radius: 5px;
            text-align: center;
            line-height: 50px;
        }

        .seat.selected {
            background-color: #28a745;
            color: white;
        }

        .seat:hover {
            background-color: green;
        }

        form {
            margin-top: 20px;
        }

        select, input[type="date"], button {
            padding: 10px;
            margin-top: 10px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #28a745;
            color: white;
            border: none;
        }

        button:hover {
            background-color: #218838;
        }

        .seat-summary {
            margin-top: 20px;
            font-size: 18px;
        }

        .seat-summary p {
            margin: 5px 0;
        }
    </style>
</head>

<body>
    <!-- <header>
        <nav>
            <div class="logo">MovieBooking</div>
            <ul>
                <li><a href="home_page.php">Home</a></li>
            </ul>
        </nav>
    </header> -->

    <section class="seat-selection">
        <h1>Select Your Seats for <?= isset($_GET['movie']) ? htmlspecialchars($_GET['movie']) : 'Unknown Movie'; ?></h1>

        <div class="screen">Screen This Way</div>

        <form id="seatForm" method="POST" action="">
            <!-- Seat grid -->
            <div class="seat-grid">
                <?php
                // Create 8 rows with 10 seats each
                for ($row = 'A'; $row <= 'H'; $row++) {
                    echo '<div class="row">';
                    for ($seat = 1; $seat <= 10; $seat++) {
                        echo '<div class="seat" data-seat="' . $row . $seat . '">' . $row . $seat . '</div>';
                    }
                    echo '</div>';
                }
                ?>
            </div>

            <input type="hidden" name="seat_number" id="selected-seat">
            <input type="hidden" name="movie_name" value="<?= isset($_GET['movie']) ? htmlspecialchars($_GET['movie']) : 'Unknown Movie'; ?>">

            <!-- Date picker -->
            <label for="movie_date">Select Date:</label>
            <input type="date" name="movie_date" id="movie_date" required>

            <!-- Timing selection -->
            <label for="timing">Select Timing:</label>
            <select name="timing" id="timing">
                <option value="10:00 AM">10:00 AM</option>
                <option value="1:00 PM">1:00 PM</option>
                <option value="4:00 PM">4:00 PM</option>
                <option value="7:00 PM">7:00 PM</option>
            </select>

            <!-- Display total selected seats and amount -->
            <div class="seat-summary">
                <p>Selected Seats: <span id="seatCount">0</span></p>
                <p>Total Amount: ₹<span id="totalAmount">0</span></p>
            </div>

            <button type="submit" id="proceedButton">Proceed to Payment</button>
        </form>
    </section>

    <script>
        // Restrict date picker to only allow future dates
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('movie_date').setAttribute('min', today);

        const seats = document.querySelectorAll('.seat');
        let selectedSeatInput = document.getElementById('selected-seat');
        let selectedSeats = [];
        const seatCount = document.getElementById('seatCount');
        const totalAmount = document.getElementById('totalAmount');
        const seatPrice = 200; // Example price per seat

        // Handle seat selection
        seats.forEach(seat => {
            seat.addEventListener('click', () => {
                const seatNumber = seat.getAttribute('data-seat');

                // Toggle seat selection
                if (selectedSeats.includes(seatNumber)) {
                    selectedSeats = selectedSeats.filter(s => s !== seatNumber);
                    seat.classList.remove('selected');
                } else {
                    selectedSeats.push(seatNumber);
                    seat.classList.add('selected');
                }

                // Update hidden input field with selected seats
                selectedSeatInput.value = selectedSeats.join(',');

                // Update seat count and total amount dynamically
                seatCount.textContent = selectedSeats.length;
                totalAmount.textContent = selectedSeats.length * seatPrice;
            });
        });
    </script>
</body>

</html>
