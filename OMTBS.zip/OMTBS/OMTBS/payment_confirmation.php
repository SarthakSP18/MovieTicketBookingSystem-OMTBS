<?php
// Simulate a payment process

// After successful payment, display the receipt
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $card_number = $_POST['card_number'];
    $expiry = $_POST['expiry'];
    $cvv = $_POST['cvv'];

    // Here you would process the payment, but for now, let's assume it's successful
    echo "<h1>Payment Successful!</h1>";
    echo "<p>Thank you for your payment, $name. Your movie booking is confirmed.</p>";
    echo "<p>Payment Details:</p>";
    echo "<p>Card Number: " . substr($card_number, -4) . "</p>";
    echo "<p>Expiry Date: $expiry</p>";
    echo "<a href='home_page.html'>Back to Home</a>";
}
?>
