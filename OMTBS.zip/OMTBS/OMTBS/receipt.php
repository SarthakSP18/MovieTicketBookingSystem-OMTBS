<?php
// Retrieve the transaction ID and payment response from PhonePe
$transactionId = $_GET['transactionId'];
$paymentStatus = $_GET['paymentStatus'];

// Verify the payment using PhonePe's API
$ch = curl_init("https://api.phonepe.com/v3/transaction/status/$transactionId");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Add the API key to the request
$headers = array(
    'Content-Type: application/json',
    'X-VERIFY: ' . hash('sha256', $transactionId . '/v3/transaction/status' . $apiKey) . '###1',
);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Execute the request
$response = curl_exec($ch);
curl_close($ch);

// Decode the response
$responseData = json_decode($response, true);

if ($responseData['success'] && $responseData['data']['status'] == 'SUCCESS') {
    // Payment was successful
    echo "Payment successful! Transaction ID: " . $transactionId;
    // Save payment details to your database and issue the ticket to the user
} else {
    // Payment failed
    echo "Payment failed!";
}
?>
    