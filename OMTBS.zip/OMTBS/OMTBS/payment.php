<?php 
session_start();

// Movie and booking details from session
$movie = isset($_SESSION['movie_name']) ? $_SESSION['movie_name'] : 'Unknown Movie';
$selected_seats = isset($_SESSION['selected_seats']) ? $_SESSION['selected_seats'] : [];
$selected_timing = isset($_SESSION['movie_timings']) ? $_SESSION['movie_timings'] : 'Unknown Timing';
$selected_date = isset($_SESSION['movie_date']) ? $_SESSION['movie_date'] : 'Unknown Date'; // Fetch selected date
$total_amount = count($selected_seats) * 200; // Assuming ticket price is ₹200 per seat

include('db_connection.php'); // Connect to the database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect user input
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password
    $transaction_id = $_POST['transaction_id']; // Get transaction ID input
    $amount = $total_amount; // Store the calculated total amount
    
    // Calculate age from date of birth
    $dob_date = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($dob_date)->y;

    // Validate user's age
    if ($age < 3) {
        $error_message = "You must be at least 3 years old to make a booking.";
    } else {
        // Insert user details into the users table
        $insert_user_query = "INSERT INTO users (full_name, dob, phone, email, password) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_user_query);
        $stmt->bind_param("sssss", $full_name, $dob, $phone, $email, $password);
        
        if ($stmt->execute()) {
            // After successful user registration, insert booking details
            $user_id = $conn->insert_id; // Get the user ID of the newly created user
            $seat_number = implode(', ', $selected_seats); // Convert seat array to string
            
            // Insert booking details into the bookings table, including amount
            $insert_booking_query = "INSERT INTO bookings (user_id, movie_name, seat_number, movie_timing, movie_date, transaction_id, amount, booking_time) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            $stmt_booking = $conn->prepare($insert_booking_query);
            $stmt_booking->bind_param("isssssd", $user_id, $movie, $seat_number, $selected_timing, $selected_date, $transaction_id, $amount);

            if ($stmt_booking->execute()) {
                // Success message upon successful booking
                $success_message = "Payment successful for $movie on $selected_date! Amount of ₹$total_amount has been received.";
            } else {
                $error_message = "Error processing the booking.";
            }
        } else {
            $error_message = "Error registering user.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .summary {
            background-color: #333;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input[type="text"], input[type="date"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 5px;
        }
        .error {
            color: red;
            margin-bottom: 20px;
        }
        .success {
            color: green;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 15px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .center {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 30%;
        }
    </style>
    <script>
        function printTicket() {
            const ticketWindow = window.open('', '_blank');
            ticketWindow.document.write('<html><head><title>Movie Ticket System</title>');
            ticketWindow.document.write('</head><body>');
            ticketWindow.document.write('<h1>Movie Ticket System</h1>');
            ticketWindow.document.write('<p><strong>Movie:</strong> <?php echo $movie; ?></p>');
            ticketWindow.document.write('<p><strong>Seats:</strong> <?php echo implode(", ", $selected_seats); ?></p>');
            ticketWindow.document.write('<p><strong>Timing:</strong> <?php echo $selected_timing; ?></p>');
            ticketWindow.document.write('<p><strong>Date:</strong> <?php echo $selected_date; ?></p>');
            ticketWindow.document.write('<p><strong>Total Amount:</strong> ₹<?php echo $total_amount; ?></p>');
            ticketWindow.document.write('</body></html>');
            ticketWindow.document.close();
            ticketWindow.print();
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Payment</h1>

        <div class="summary">
            <h3>Booking Summary</h3>
            <p><strong>Movie:</strong> <?php echo $movie; ?></p>
            <p><strong>Seats:</strong> <?php echo implode(', ', $selected_seats); ?></p>
            <p><strong>Timing:</strong> <?php echo $selected_timing; ?></p>
            <p><strong>Date:</strong> <?php echo $selected_date; ?></p>
            <p><strong>Total Amount:</strong> ₹<?php echo $total_amount; ?></p>
        </div>

        <!-- Display any success or error message -->
        <?php if (!empty($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="success"><?php echo $success_message; ?></div>
            <button onclick="printTicket()">Download/Print Ticket</button>
        <?php else: ?>
            <form action="payment.php" method="POST">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" name="full_name" id="full_name" required>
                </div>

                <div class="form-group">
                    <label for="dob">Date of Birth</label>
                    <input type="date" name="dob" id="dob" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="text" name="phone" id="phone" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" required>
                </div>

                <div class="form-group">
                    <label for="password">Set Password</label>
                    <input type="password" name="password" id="password" required>
                </div>

                
                <b>Scan & Pay Here</b>
                <div class="form-group">
                    <label for="scanner">
                        <img src="scannerfinal.jpeg" class="center" alt="Scan QR code to pay">
                    </label>
                </div>
                <div class="form-group">
                    <label for="transaction_id">Enter Transaction ID</label>
                    <input type="text" name="transaction_id" id="transaction_id" required>
                </div>

                <button type="submit">Pay Now</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
