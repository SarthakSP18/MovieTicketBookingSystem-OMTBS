<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit();
}

// Connect to the database
include('db_connection.php');

// Fetch booking and payment details from the bookings table
$sql = "
    SELECT b.id, b.transaction_id, b.movie_name, b.movie_timing, b.movie_date, b.seat_number, 
           b.amount,  b.booking_time, u.full_name, u.phone
    FROM bookings b
    LEFT JOIN users u ON b.user_id = u.id";
$result = $conn->query($sql);

// Check if the query returns data
if (!$result) {
    die("Error retrieving booking data: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payments</title>
    <link rel="stylesheet" href="admin_styles.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="view_users.php">View Users</a></li>
                <li><a href="view_payments.php">View Payments</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <h1>All Transactions</h1>

        <table>
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Transaction ID</th>
                    <th>Movie</th>
                    <th>User</th>
                    <th>Phone</th>
                    <th>Show Date & Time</th>
                    <th>Seats</th>
                  
                    <th>Amount</th>
                    <th>Booking Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['transaction_id']}</td>
                                <td>{$row['movie_name']}</td>
                                <td>{$row['full_name']}</td>
                                <td>{$row['phone']}</td>
                                <td>{$row['movie_timing']} ({$row['movie_date']})</td>
                                <td>{$row['seat_number']}</td>
                              
                                <td>₹{$row['amount']}</td>
                                <td>{$row['booking_time']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='10'>No transactions found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>
</body>

</html>

<?php
$conn->close();
?>
