<?php 
session_start();

// Movie and booking details from session
$movie = isset($_SESSION['movie_name']) ? $_SESSION['movie_name'] : 'Unknown Movie';
$selected_seats = isset($_SESSION['selected_seats']) ? $_SESSION['selected_seats'] : [];
$selected_timing = isset($_SESSION['movie_timings']) ? $_SESSION['movie_timings'] : 'Unknown Timing';
$selected_date = isset($_SESSION['movie_date']) ? $_SESSION['movie_date'] : 'Unknown Date';
$total_amount = count($selected_seats) * 200;

include('db_connection.php'); // Connect to the database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect user input
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password
    $address = $_POST['address']; // New address field
    $transaction_id = $_POST['transaction_id'];
    $amount = $total_amount;
    
    // Calculate age from date of birth
    $dob_date = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($dob_date)->y;

    if (strlen($phone) != 10 || !ctype_digit($phone)) {
        $error_message = "Phone number must be exactly 10 digits.";
    } else if ($age < 3) {
        $error_message = "You must be at least 3 years old to make a booking.";
    } else {
        // Insert user details into the users table
        $insert_user_query = "INSERT INTO users (full_name, dob, phone, email, password, address) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_user_query);
        $stmt->bind_param("ssssss", $full_name, $dob, $phone, $email, $password, $address);
    
        if ($stmt->execute()) {
            // Proceed with booking details
            $user_id = $conn->insert_id;
            $seat_number = implode(', ', $selected_seats);
            
            $insert_booking_query = "INSERT INTO bookings (user_id, movie_name, seat_number, movie_timing, movie_date, transaction_id, amount, booking_time) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            $stmt_booking = $conn->prepare($insert_booking_query);
            $stmt_booking->bind_param("isssssd", $user_id, $movie, $seat_number, $selected_timing, $selected_date, $transaction_id, $amount);
    
            if ($stmt_booking->execute()) {
                $success_message = "Payment successful for $movie on $selected_date! Amount of ₹$total_amount has been received.";
            } else {
                $error_message = "Error processing the booking.";
            }
        } else {
            $error_message = "Error registering user.";
        }
    }
}    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            background-color: #f4f4f4;
            padding-top: 60px;
            background: url('payment_bg.jpg') no-repeat center center/cover;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .summary {
            background-color: #333;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input[type="text"], input[type="date"], input[type="email"], input[type="password"] {
            width: 98%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 5px;
        }
        .error {
            color: red;
            margin-bottom: 20px;
        }
        .success {
            color: green;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 15px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        /* button:hover {
            background-color: #218838;
        } */
        .password-container {
            position: relative;
            width: 100%;
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            left: 260px;
            top: 55%;
            transform: translateY(-50%);
            border: none;
            background: none;
            font-size: 16px;
            /* Smaller size */
            color: black;
            cursor: pointer;
            padding: 0;
            /* Remove extra padding */
            height: 1px;
        }
        
.center {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 30%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment</h1>

        <div class="summary">
            <h3>Booking Summary</h3>
            <p><strong>Movie:</strong> <?php echo $movie; ?></p>
            <p><strong>Seats:</strong> <?php echo implode(', ', $selected_seats); ?></p>
            <p><strong>Timing:</strong> <?php echo $selected_timing; ?></p>
            <p><strong>Date:</strong> <?php echo $selected_date; ?></p>
            <p><strong>Total Amount:</strong> ₹<?php echo $total_amount; ?></p>
        </div>

        <?php if (!empty($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="success"><?php echo $success_message; ?></div>
            <button onclick="printTicket()">Download/Print Ticket</button>
        <?php else: ?>
            <form action="payment.php" method="POST">
                <div class="form-group">
                    <label for="full_name">Enter Full Name</label>
                    <input type="text" name="full_name" id="full_name" required>
                </div>

                <div class="form-group">
                    <label for="dob">Enter Date of Birth</label>
                    <input type="date" name="dob" id="dob" required>
                </div>

                <div class="form-group">
                    <label for="phone">Enter Phone Number</label>
                    <input type="text" name="phone" id="phone" placeholder="Enter exactly 10 digits" pattern="\d{10}" title="Phone number must be exactly 10 digits" required>
                </div>

                <div class="form-group">
                    <label for="email">Enter Email Id</label>
                    <input type="email" name="email" id="email" required>
                </div>

                <div class="form-group">
                    <label for="address">Enter Address</label>
                    <input type="text" name="address" id="address" required>
                </div>

                <div class="form-group password-container">
                    <label for="password">Set New Password</label>
                    <input type="password" id="password" name="password" required>
                    <button type="button" class="toggle-password" onclick="togglePassword()">👁️</button>
                </div>

                <b>Scan & Pay Here</b>
                <div class="form-group">
                    <label for="scanner">
                        <img src="scannerfinal.jpeg" class="center" alt="Scan QR code to pay">
                    </label>
                </div>
                <div class="form-group">
                    <label for="transaction_id">Enter Transaction ID</label>
                    <input type="text" name="transaction_id" id="transaction_id" required>
                </div>

                <button type="submit">Pay Now</button>
            </form>
        <?php endif; ?>
        
        <script>
            function togglePassword() {
                const passwordInput = document.getElementById('password');
                const toggleButton = document.querySelector('.toggle-password');
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    toggleButton.innerHTML = '👁️‍🗨️';
                } else {
                    passwordInput.type = 'password';
                    toggleButton.innerHTML = '👁️';
                }
            }
            function printTicket() {
            const ticketWindow = window.open('', '_blank');
            ticketWindow.document.write('<html><head><title>Movie Ticket System</title>');
            ticketWindow.document.write('</head><body>');
            ticketWindow.document.write('<h1>Movie Ticket System</h1>');
            ticketWindow.document.write('<p><strong>Movie:</strong> <?php echo $movie; ?></p>');
            ticketWindow.document.write('<p><strong>Seats:</strong> <?php echo implode(", ", $selected_seats); ?></p>');
            ticketWindow.document.write('<p><strong>Timing:</strong> <?php echo $selected_timing; ?></p>');
            ticketWindow.document.write('<p><strong>Date:</strong> <?php echo $selected_date; ?></p>');
            ticketWindow.document.write('<p><strong>Total Amount:</strong> ₹<?php echo $total_amount; ?></p>');
            ticketWindow.document.write('</body></html>');
            ticketWindow.document.close();
            ticketWindow.print();
        }
        </script>
    </div>
</body>
</html>