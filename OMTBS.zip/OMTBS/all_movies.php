<?php
require 'db_connection.php';

// Get filters from query parameters
$genre = isset($_GET['genre']) && $_GET['genre'] != 'all' ? $_GET['genre'] : '';
$language = isset($_GET['language']) && $_GET['language'] != 'all' ? $_GET['language'] : '';

// Query to fetch movies from the database
$query = "SELECT * FROM movies WHERE 1=1";

// Apply filters to the query
if ($genre) {
    $query .= " AND genre='$genre'";
}
if ($language) {
    $query .= " AND language='$language'";
}

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movies - BookMyShow Clone</title>
    <link rel="stylesheet" href="all_movies.css">
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="home_page.html">Home</a></li>
                <li><a href="user_register.html">Login</a></li>
            </ul>
        </nav>
    </header>

    <section class="movie-filter-section">
        <h2>Search & Filter Movies</h2>
        <form action="all_movies.php" method="GET">
            <label for="genre">Genre:</label>
            <select name="genre" id="genre">
                <option value="all">All</option>
                <option value="action" <?php if($genre == 'action') echo 'selected'; ?>>Action</option>
                <option value="comedy" <?php if($genre == 'comedy') echo 'selected'; ?>>Comedy</option>
                <option value="drama" <?php if($genre == 'drama') echo 'selected'; ?>>Drama</option>
            </select>

            <label for="language">Language:</label>
            <select name="language" id="language">
                <option value="all">All</option>
                <option value="english" <?php if($language == 'english') echo 'selected'; ?>>English</option>
                <option value="hindi" <?php if($language == 'hindi') echo 'selected'; ?>>Hindi</option>
                <option value="regional" <?php if($language == 'regional') echo 'selected'; ?>>Regional</option>
            </select>

            <button type="submit" class="btn">Search</button>
        </form>
    </section>

    <section class="movie-list">
        <h2>Movies</h2>
        <div class="movies">
            <?php if ($result->num_rows > 0) { ?>
                <?php while ($movie = $result->fetch_assoc()) { ?>
                    <div class="movie-card">
    <img src="images/<?php echo $movie['image_path']; ?>" alt="<?php echo $movie['name']; ?>">
    <h3><?php echo $movie['name']; ?></h3>
    <p>Genre: <?php echo $movie['genre']; ?></p>
    <p>Language: <?php echo $movie['language']; ?></p>
    <a href="select_movie.php?movie_id=<?php echo $movie['id']; ?>" class="btn">Book Now</a>
</div>
                <?php } ?>
            <?php } else { ?>
                <p>No movies found for the selected filters.</p>
            <?php } ?>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 MovieBooking..</p>
    </footer>
</body>

</html>
