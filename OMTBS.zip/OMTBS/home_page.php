<?php
require 'db_connection.php';

// Update the visitor count in the database each time the page is loaded
$sql = "UPDATE statistics SET visitor_count = visitor_count + 1 WHERE id = 1";
if ($conn->query($sql) !== TRUE) {
    echo "Error updating visitor count: " . $conn->error;
}

// Fetch movies from the database
$query = "SELECT * FROM movies";
$result = mysqli_query($conn, $query);
$movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Ticket Booking</title>
    <link rel="stylesheet" href="home_page.css">
    <style>
        /* Quick Styles */
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
          
        }

        header {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header .logo a {
            color: white;
            text-decoration: none;
            font-size: 24px;
        }

        header ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        header ul li {
            margin-left: 20px;
        }

        header ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-family: Georgia, 'Times New Roman', Times, serif;

        }

        header ul li a:hover {
            text-decoration: none;
        }

        .hero {
            background: url('admin_bg.jpg') no-repeat center center/cover;
            color: white;
            padding: 100px 0;
            text-align: center;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
        }

        .hero h1 {
            font-size: 48px;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 20px;
            font-family: Georgia, 'Times New Roman', Times, serif;

        }

        .featured-movies {
            padding: 20px;
            text-align: center;
        }

        .featured-movies h2 {
            margin-bottom: 30px;
            font-size: 32px;
        }

        .movie-grid {
            display:flex;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            
        }

        .movie-card {
            position: relative;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            text-align: center;
            background-color: #f9f9f9;
        }

        .movie-card img {
    width: 100%;
    height: 300px;
    object-fit: contain; /* Ensures the image fits inside without cropping */
    background-color: #000; /* Add a background to handle aspect ratio differences */
}


        .movie-card h3 {
            margin: 10px 0;
            font-size: 20px;
            font-family: Georgia, 'Times New Roman', Times, serif;

        }

        .movie-card p {
            color: #666;
        }

        .movie-card .btn {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 10px;
        }

        .movie-card .btn:hover {
            background-color: #0056b3;
        }

        /* Trailer Button */
        .trailer-btn {
            display: none;
            position: absolute;
            top: 220px; /* Position at the top of the card */
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            color: red;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
        }

        .movie-card:hover .trailer-btn {
            display: block;
        }

        footer {
            background-color: #333;
            color: white;
            padding: 20px;
            text-align: center;
        }

        footer a {
            color: lightblue;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        footer img {
            width: 20px;
            margin-left: 5px;
        }
    </style>
</head>

<body>
    <!-- Header Section -->
    <header>
        <div class="logo">
            <a href="admin_login.html">Movie Booking</a>
        </div>
        <ul>
            <li><a href="home_page.php">Home</a></li>
            <li><a href="contact_us.php">Contact-Us</a></li>

            <!-- <li><a href="all_movies.html">Movies</a></li> -->
            <li><a href="user_login.php" class="btn">Login</a></li>
        </ul>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Book Your Favorite Movie Tickets Now</h1>
        </div>
    </section>

    <!-- Featured Movies Section -->
    <section class="featured-movies">
        <h2>Now Showing... Hurry Up!</h2>
        <div class="movie-grid">
            <?php foreach ($movies as $movie): ?>
                <div class="movie-card">
                    <img src="<?= $movie['poster'] ?>" alt="<?= $movie['name'] ?>">
                    <h3><?= $movie['name'] ?></h3>
                    <p><?= $movie['genre'] ?></p>
                    <a href="seats.php?movie=<?= urlencode($movie['name']) ?>" class="btn">Book Now</a>
                    <a href="<?= $movie['trailer'] ?>" class="trailer-btn" target="_blank">View Trailer</a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2024 MovieBooking</p>
        <a href="https://www.instagram.com/sarthakpomane18?igshid=YmI5MnF1NWpxemcx" target="_blank" class="instagram-icon">
            Any queries? Contact
            <img src="insta_logo.jpg" alt="Instagram">
        </a>
    </footer>
</body>

</html>
