<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.html");
    exit();
}

include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $genre = $_POST['genre'];
    $description = $_POST['description'];
    $trailer = $_POST['trailer']; // Get trailer URL

    // Handling file upload for poster
    $target_dir = "movie images/";
    $target_file = $target_dir . basename($_FILES["movie_poster"]["name"]);
    move_uploaded_file($_FILES["movie_poster"]["tmp_name"], $target_file);

    $query = "INSERT INTO movies (name, genre, description, poster, trailer) VALUES ('$name', '$genre', '$description', '$target_file', '$trailer')";
    mysqli_query($conn, $query);
    header("Location: admin_dashboard.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Movie</title>
    <link rel="stylesheet" href="admin_styles.css">
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="add_movie.php">Add Movie</a></li>
                <li><a href="view_users.php">View Users</a></li>
                <li><a href="view_payments.php">View Payments</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <h1>Add a New Movie</h1>
        <form action="add_movie.php" method="POST" enctype="multipart/form-data">
            <label for="name">Movie Name:</label>
            <input type="text" id="name" name="name" required><br><br>

            <label for="genre">Genre:</label>
            <input type="text" id="genre" name="genre" required><br><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea><br><br>

            <label for="movie_poster">Movie Poster:</label>
            <input type="file" id="movie_poster" name="movie_poster" accept="image/*" required><br><br>

            <label for="trailer">Trailer URL:</label>
            <input type="text" id="trailer" name="trailer" placeholder="YouTube trailer URL" required><br><br>

            <button type="submit" class="btn">Add Movie</button>
        </form>
    </section>

    <style>
        section {
            padding: 20px;
        }

        label, input, textarea {
            display: block;
            margin-bottom: 10px;
        }

        textarea {
            width: 100%;
            height: 100px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #218838;
        }
    </style>
</body>

</html>
