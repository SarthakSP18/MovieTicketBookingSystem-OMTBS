-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2024 at 08:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_booking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(3, 'sarthak', '$2y$10$yjqiQ6JYjVL7ctic31Q8A.7yerisbb1U.1jdXXcpoaxxOcRPd6tk6'),
(4, 'abhijeet', '$2y$10$Z03NNFRauPyJ1iUKabqDk.ZGc8OzN0XkNblcXMhDKyyx9vi1hADFi');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `movie_name` varchar(255) NOT NULL,
  `seat_number` varchar(255) NOT NULL,
  `movie_timing` varchar(100) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `booking_time` timestamp NULL DEFAULT current_timestamp(),
  `movie_date` date DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `movie_name`, `seat_number`, `movie_timing`, `transaction_id`, `user_id`, `booking_time`, `movie_date`, `amount`) VALUES
(1, 'Pushpa 2', 'D3', '4:00 PM', '', 1, '2024-09-22 10:48:32', NULL, 0.00),
(2, 'Pushpa 2', 'D3', '4:00 PM', '', 1, '2024-09-22 10:50:48', NULL, 0.00),
(3, 'Pushpa 2', 'D3', '4:00 PM', '', 1, '2024-09-22 11:05:32', NULL, 0.00),
(4, 'GOAT', 'E5, E6', '10:00 AM', '', 1, '2024-09-22 11:06:18', NULL, 0.00),
(5, 'Deadpool Wolverine', 'G5, G6', '7:00 PM', '2134546556543', 9, '2024-09-28 18:08:27', '2024-09-29', 0.00),
(6, 'GOAT', 'G5, G6', '4:00 PM', '1020304050', 10, '2024-09-29 17:45:20', '2024-10-01', 400.00),
(7, 'John Wick', 'H5', '4:00 PM', '12233233145423', 11, '2024-10-09 17:25:53', '2024-10-17', 200.00),
(8, 'John Wick', 'H5', '4:00 PM', '12233233145423', 12, '2024-10-09 17:32:44', '2024-10-17', 200.00),
(9, 'John Wick', 'H5', '4:00 PM', '12233233145423', 13, '2024-10-09 17:33:51', '2024-10-17', 200.00),
(10, 'John Wick', 'H5', '4:00 PM', '12233233145423', 14, '2024-10-09 17:36:10', '2024-10-17', 200.00),
(11, 'John Wick', 'F5', '4:00 PM', '4353423245542', 15, '2024-10-09 17:55:05', '2024-10-10', 200.00);

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `genre` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `poster` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `language` varchar(50) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `trailer` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `name`, `genre`, `description`, `poster`, `created_at`, `language`, `image_path`, `trailer`) VALUES
(5, 'GOAT', 'Action | Drama', '', 'goat.jpg', '2024-09-22 06:49:47', NULL, 'goat.jpg', 'https://youtu.be/Uf8rt635LLo?si=ZyqHMRcszpdFfiiC'),
(6, 'Double Ismart', 'Comedy | Romance', '', 'double_Ismart.jpg', '2024-09-22 06:49:47', NULL, 'double_Ismart.jpg', 'https://youtu.be/OOhbzK-BBnc?si=daP6b_I9H4BuYC8_'),
(7, 'Pushpa 2', 'Thriller | Mystery', '', 'Pushpa2.jpg', '2024-09-22 06:49:47', NULL, 'Pushpa2.jpg', 'https://youtu.be/aKJRmWnRXrw?si=f6y9DluvhYOrpmsm'),
(8, 'Deadpool Wolverine', 'Drama | Romance', '', 'deadpoolwolverine.jpg', '2024-09-22 06:49:47', NULL, 'deadpoolwolverine.jpg', 'https://youtu.be/TUaR3Mf3PFo?si=xXXR3_TeneJcTiD6'),
(9, 'Yarriyan 2', 'Action | Thriller', '', 'yarriyan2.jpg', '2024-09-22 06:49:47', NULL, 'yarriyan2.jpg', 'https://youtu.be/XRgVik3IsPU?si=sdgz6epZrboHlc4c'),
(10, 'John Wick', 'Comedy | Adventure', '', 'johnwick.jpg', '2024-09-22 06:49:47', NULL, 'johnwick.jpg', 'https://youtu.be/9YRVT_xywcs?si=c_3ZLa0bmNhd2bBo');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `booking_id`, `transaction_id`, `amount`, `created_at`) VALUES
(1, 1, 'TXN_66eff600ec1774.35417882', 200.00, '2024-09-22 10:48:33'),
(2, 2, 'TXN_66eff688a597a8.58007349', 200.00, '2024-09-22 10:50:48'),
(3, 3, 'TXN_66eff9fc6a8f90.87748917', 200.00, '2024-09-22 11:05:32'),
(4, 4, 'TXN_66effa2aabaab7.13712698', 400.00, '2024-09-22 11:06:18');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `seat_number` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statistics`
--

CREATE TABLE `statistics` (
  `id` int(11) NOT NULL,
  `visitor_count` int(11) DEFAULT 0,
  `seats_booked` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `statistics`
--

INSERT INTO `statistics` (`id`, `visitor_count`, `seats_booked`) VALUES
(1, 115, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `dob`, `phone`, `email`, `address`, `password`, `created_at`) VALUES
(1, 'sarthak sadhu pomane', '2004-03-08', '9172860370', 'sarthakpomane123@gmail.com', '', '$2y$10$Xmil941Q.o5XX4em0yrI7.GrVjd.XV4Q82r7.ShMesqDyYuQWB2hi', '2024-09-28 17:19:45'),
(2, 'sarthak sadhu pomane', '2004-03-08', '9172860370', 'sarthakpomane123@gmail.com', '', '$2y$10$Y8KEzfYhSIVwEZts19xTY.PzkyMwPSYAQ/t1Fp65YHFGUWA.TJK8q', '2024-09-28 17:20:19'),
(3, 'sarthak sadhu pomane', '2004-03-08', '9172860370', 'sarthakpomane123@gmail.com', '', '$2y$10$LR9DvkTOqJPYQcRDb1gaIO47wXs7LwxGx9MvBTiitWCfX4MOzEPwq', '2024-09-28 17:24:40'),
(4, 'sarthak sadhu pomane', '2004-03-08', '9172860370', 'sarthakpomane123@gmail.com', '', '$2y$10$QvCkJsoOMJoFP5DVShByGukBULzJpevXs0Nu0K3JdJnLT0VMg4Veu', '2024-09-28 17:30:50'),
(5, 'a b c', '2000-11-12', '1234567890', 'abhi@gmal.com', '', '$2y$10$zOehVUSBuK.Kiv.czctz7e56mrV1s50E4/WdggXeKCBKiyoJgoI1S', '2024-09-28 17:55:58'),
(6, 'a b c', '2000-11-12', '1234567890', 'abhi@gmal.com', '', '$2y$10$ibpwX6TZQ8qevyOuoGgCKOdZgJPXkWCYoh8DE2XmSV8Q0w.BI.ZWe', '2024-09-28 17:57:42'),
(7, 'a b c', '2000-11-12', '1234567890', 'abhi@gmal.com', '', '$2y$10$RSh5mYwsTUV.cKjNAULbvO9Gd/DnM32GWa1Z5VTvFwgO05bLnpIK2', '2024-09-28 17:58:53'),
(8, 'a b c', '2000-11-12', '1234567890', 'abhi@gmal.com', '', '$2y$10$JKAOGjIRzDbgmimHdqseweRVnFx3PrjpgtH1YtyO2Vl5kZOsssHIy', '2024-09-28 18:01:13'),
(9, 'a b c', '2000-11-12', '1234567890', 'abhi@gmal.com', '', '$2y$10$IngcSBURY1diiuqoK.y8L.AYk0u98R51iihsyqFcp2JMjiTIGBO8y', '2024-09-28 18:08:27'),
(10, 'pehle hi badnaam hai', '1950-03-08', '1020304050', 'abc@gmail.com', '', '$2y$10$EYmZqWBp.3X/IrRlIvSdZ.iazEgLB4Xd/YM4Rgk2nHxSaS7OMvLuO', '2024-09-29 17:45:19'),
(11, 'tomya bhai', '2004-08-03', '1010101010', 'old@gmail.com', 'pass@gmail.com', '$2y$10$FlTnEeyRQmraHnrzvQebWuQXIbZVqrZzSBMqqE3QNj00ahbT9jnae', '2024-10-09 17:25:53'),
(12, 'tomya bhai', '2004-08-03', '1010101010', 'old@gmail.com', 'pass@gmail.com', '$2y$10$0qPBv8/Djoexms0Gpb2JROS32hw84CwiJvVZW4kBCgp2l4MKX6lLK', '2024-10-09 17:32:44'),
(13, 'tomya bhai', '2004-08-03', '1010101010', 'old@gmail.com', 'pass@gmail.com', '$2y$10$3Cu19yolW7po5zLrO/qLLuIWbqvRcQXcgxqnn3rVKt5Jkp0ZbCD/y', '2024-10-09 17:33:51'),
(14, 'tomya bhai', '2004-08-03', '1010101010', 'old@gmail.com', 'pass@gmail.com', '$2y$10$sBMJH0InqgWyzWFwuoEL6Ol4RxxL2uMhY8iyEJ4OILxVMprYiNkq2', '2024-10-09 17:36:09'),
(15, 's s p', '2003-01-02', '1233124342', 'de@gmail.com', 'rrewvc , 24', '$2y$10$pKaNWk7QZJ2jN4hNJHCj2egJLMsz3eSudEgBXKkRJn4zuLKeLcnxK', '2024-10-09 17:55:05');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `visit_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `movie_id` (`movie_id`);

--
-- Indexes for table `statistics`
--
ALTER TABLE `statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statistics`
--
ALTER TABLE `statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `seats`
--
ALTER TABLE `seats`
  ADD CONSTRAINT `seats_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
