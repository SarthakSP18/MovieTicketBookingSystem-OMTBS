<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'movie_booking_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$booking_id = $_GET['booking_id'];

// Retrieve booking and payment details
$sql = "SELECT * FROM bookings WHERE id = $booking_id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $booking = $result->fetch_assoc();
    $movie_name = $booking['movie_name'];
    $selected_seats = $booking['selected_seats'];
    $timing = $booking['timing'];
}

// Output ticket as HTML
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=ticket.jpg");

echo "<h1>Movie Ticket</h1>";
echo "<p><strong>Movie:</strong> $movie_name</p>";
echo "<p><strong>Seats:</strong> $selected_seats</p>";
echo "<p><strong>Timing:</strong> $timing</p>";
echo "<p>Thank you for booking with us!</p>";

$conn->close();
?>
